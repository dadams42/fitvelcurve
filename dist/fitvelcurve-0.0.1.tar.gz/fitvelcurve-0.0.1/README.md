# fitvelcurve
Derived dark matter density profiles from rotation curves.
Additional description: We fit an NFW profile using dynesty to synthetic (mock) rotation curve data and validate against the underlying profile for the halo.
